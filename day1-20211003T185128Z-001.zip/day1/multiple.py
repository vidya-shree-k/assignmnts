class Magic:
   def func1(self):
        print("You are going to learn magic")
class Hogwarts:
   def func2(self):
        print("wecome to Hogwarts")
class Slytherin(Magic , Hogwarts):
    def func3(self):
        print("Slytherin is the cunning team in Hogwarts to learn Magic")
 
ob = Slytherin()
ob.func1()
ob.func2()
ob.func3()