class Hogwarts:
     def func1(self):
          print("welcome to the Hogwarts")
class Grifinder(Hogwarts):
     def func2(self):
          print("HarryPotter belongs to Grifinder in Hogwarts")
ob = Grifinder()
ob.func1()
ob.func2()